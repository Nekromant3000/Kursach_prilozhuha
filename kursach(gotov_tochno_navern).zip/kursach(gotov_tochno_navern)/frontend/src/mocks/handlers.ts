import { http, HttpResponse } from 'msw';
import { mockUsers, mockBooks, mockBorrowings } from './data';
import { LoginRequest, RegisterRequest, BorrowRequest } from '../types';

const API_BASE = 'http://127.0.0.1:8000/api';

let borrowings = [...mockBorrowings];
let nextBorrowingId = 4;
let nextUserId = 3;

export const handlers = [
  http.post(`${API_BASE}/login`, async ({ request }) => {
    const body = await request.json() as LoginRequest;
    const user = mockUsers.find(u => u.email === body.email);

    if (user && body.password === 'password123') {
      return HttpResponse.json({
        access_token: `fake-jwt-token-${user.id}`,
        user
      });
    }

    return HttpResponse.json(
      { message: 'Invalid credentials' },
      { status: 401 }
    );
  }),

  http.post(`${API_BASE}/register`, async ({ request }) => {
    const body = await request.json() as RegisterRequest;

    const newUser = {
      id: nextUserId++,
      name: body.name,
      email: body.email,
      role: 'reader' as const
    };

    return HttpResponse.json({
      message: 'User registered successfully',
      access_token: `fake-jwt-token-${newUser.id}`,
      user: newUser
    });
  }),

  http.get(`${API_BASE}/me`, ({ request }) => {
    const authHeader = request.headers.get('Authorization');

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return HttpResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    const userId = parseInt(token.split('-').pop() || '0');
    const user = mockUsers.find(u => u.id === userId);

    if (user) {
      return HttpResponse.json(user);
    }

    return HttpResponse.json(
      { message: 'User not found' },
      { status: 404 }
    );
  }),

  http.get(`${API_BASE}/books`, ({ request }) => {
    const url = new URL(request.url);
    const genre = url.searchParams.get('genre');
    const author = url.searchParams.get('author');
    const year = url.searchParams.get('year');
    const search = url.searchParams.get('search');
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = 10;

    let filtered = [...mockBooks];

    if (genre) {
      filtered = filtered.filter(book => book.genre === genre);
    }

    if (author) {
      filtered = filtered.filter(book => book.author === author);
    }

    if (year) {
      filtered = filtered.filter(book => book.year === parseInt(year));
    }

    if (search) {
      filtered = filtered.filter(book =>
        book.title.toLowerCase().includes(search.toLowerCase())
      );
    }

    const start = (page - 1) * limit;
    const end = start + limit;
    const paginatedBooks = filtered.slice(start, end);

    return HttpResponse.json({
      data: paginatedBooks,
      total: filtered.length,
      page,
      totalPages: Math.ceil(filtered.length / limit)
    });
  }),

  http.get(`${API_BASE}/books/:id`, ({ params }) => {
    const bookId = parseInt(params.id as string);
    const book = mockBooks.find(b => b.id === bookId);

    if (book) {
      const borrowing = borrowings.find(b => b.bookId === bookId && !b.returned);
      return HttpResponse.json({
        ...book,
        borrowing: borrowing || null
      });
    }

    return HttpResponse.json(
      { message: 'Book not found' },
      { status: 404 }
    );
  }),

  http.post(`${API_BASE}/borrow`, async ({ request }) => {
    const authHeader = request.headers.get('Authorization');

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return HttpResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    const userId = parseInt(token.split('-').pop() || '0');
    const body = await request.json() as BorrowRequest;

    const book = mockBooks.find(b => b.id === body.bookId);

    if (!book) {
      return HttpResponse.json(
        { message: 'Book not found' },
        { status: 404 }
      );
    }

    if (!book.available) {
      return HttpResponse.json(
        { message: 'Book is not available' },
        { status: 400 }
      );
    }

    const newBorrowing = {
      id: nextBorrowingId++,
      bookId: body.bookId,
      userId,
      startDate: body.startDate,
      endDate: body.endDate,
      returned: false
    };

    borrowings.push(newBorrowing);
    book.available = false;

    return HttpResponse.json({
      message: 'Book borrowed successfully',
      borrowing: newBorrowing
    });
  }),

  http.post(`${API_BASE}/return/:id`, ({ params, request }) => {
    const authHeader = request.headers.get('Authorization');

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return HttpResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const borrowingId = parseInt(params.id as string);
    const borrowing = borrowings.find(b => b.id === borrowingId);

    if (!borrowing) {
      return HttpResponse.json(
        { message: 'Borrowing not found' },
        { status: 404 }
      );
    }

    borrowing.returned = true;
    const book = mockBooks.find(b => b.id === borrowing.bookId);
    if (book) {
      book.available = true;
    }

    return HttpResponse.json({
      message: 'Book returned successfully'
    });
  }),

  http.get(`${API_BASE}/borrow/my`, ({ request }) => {
    const authHeader = request.headers.get('Authorization');

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return HttpResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    const userId = parseInt(token.split('-').pop() || '0');

    const userBorrowings = borrowings
      .filter(b => b.userId === userId && !b.returned)
      .map(borrowing => {
        const book = mockBooks.find(b => b.id === borrowing.bookId);
        return {
          ...borrowing,
          book
        };
      });

    return HttpResponse.json(userBorrowings);
  })
];
