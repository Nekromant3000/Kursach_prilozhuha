import { Book, User, Borrowing } from '../types';

export const mockUsers: User[] = [
  {
    id: 1,
    name: "Иван Петров",
    email: "reader@example.com",
    role: "reader"
  },
  {
    id: 2,
    name: "Мария Сидорова",
    email: "admin@example.com",
    role: "admin"
  }
];

export const mockBooks: Book[] = [
  {
    id: 1,
    title: "Мастер и Маргарита",
    author: "Михаил Булгаков",
    genre: "Роман",
    year: 1967,
    image: "https://images.pexels.com/photos/256450/pexels-photo-256450.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Роман Михаила Булгакова, работа над которым началась в конце 1920-х годов и продолжалась вплоть до смерти писателя.",
    available: true
  },
  {
    id: 2,
    title: "Война и мир",
    author: "Лев Толстой",
    genre: "Роман-эпопея",
    year: 1869,
    image: "https://images.pexels.com/photos/1130980/pexels-photo-1130980.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Роман-эпопея Льва Толстого, описывающий русское общество в эпоху войн против Наполеона в 1805—1812 годах.",
    available: false
  },
  {
    id: 3,
    title: "Преступление и наказание",
    author: "Фёдор Достоевский",
    genre: "Роман",
    year: 1866,
    image: "https://images.pexels.com/photos/415071/pexels-photo-415071.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Социально-философский и социально-психологический роман Фёдора Достоевского.",
    available: true
  },
  {
    id: 4,
    title: "Евгений Онегин",
    author: "Александр Пушкин",
    genre: "Роман в стихах",
    year: 1833,
    image: "https://images.pexels.com/photos/694740/pexels-photo-694740.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Роман в стихах Александра Пушкина, одно из самых значительных произведений русской словесности.",
    available: true
  },
  {
    id: 5,
    title: "Анна Каренина",
    author: "Лев Толстой",
    genre: "Роман",
    year: 1877,
    image: "https://images.pexels.com/photos/1370295/pexels-photo-1370295.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Роман Льва Толстого о трагической любви замужней дамы Анны Карениной и блестящего офицера Вронского.",
    available: true
  },
  {
    id: 6,
    title: "Мёртвые души",
    author: "Николай Гоголь",
    genre: "Поэма",
    year: 1842,
    image: "https://images.pexels.com/photos/46274/pexels-photo-46274.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Прозаическая поэма Николая Гоголя, одно из выдающихся произведений русской литературы.",
    available: false
  },
  {
    id: 7,
    title: "Идиот",
    author: "Фёдор Достоевский",
    genre: "Роман",
    year: 1869,
    image: "https://images.pexels.com/photos/1301585/pexels-photo-1301585.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Роман Фёдора Достоевского, в котором писатель впервые с подлинной страстью воплотил давно задуманный образ.",
    available: true
  },
  {
    id: 8,
    title: "Герой нашего времени",
    author: "Михаил Лермонтов",
    genre: "Роман",
    year: 1840,
    image: "https://images.pexels.com/photos/1261180/pexels-photo-1261180.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Первый в русской прозе лирико-психологический роман, написанный Михаилом Лермонтовым.",
    available: true
  },
  {
    id: 9,
    title: "Отцы и дети",
    author: "Иван Тургенев",
    genre: "Роман",
    year: 1862,
    image: "https://images.pexels.com/photos/159866/books-book-pages-read-159866.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Роман Ивана Тургенева, написанный в 1860—1861 годах и опубликованный в 1862 году.",
    available: true
  },
  {
    id: 10,
    title: "Вишнёвый сад",
    author: "Антон Чехов",
    genre: "Пьеса",
    year: 1904,
    image: "https://images.pexels.com/photos/1370295/pexels-photo-1370295.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Пьеса в четырёх действиях Антона Чехова, жанр которой сам автор определил как комедию.",
    available: true
  },
  {
    id: 11,
    title: "Братья Карамазовы",
    author: "Фёдор Достоевский",
    genre: "Роман",
    year: 1880,
    image: "https://images.pexels.com/photos/1907785/pexels-photo-1907785.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Последний роман Фёдора Достоевского, над которым писатель работал два года.",
    available: false
  },
  {
    id: 12,
    title: "Обломов",
    author: "Иван Гончаров",
    genre: "Роман",
    year: 1859,
    image: "https://images.pexels.com/photos/2908984/pexels-photo-2908984.jpeg?auto=compress&cs=tinysrgb&w=400",
    description: "Роман Ивана Гончарова, написанный в 1859 году. Один из самых известных романов русской литературы.",
    available: true
  }
];

export const mockBorrowings: Borrowing[] = [
  {
    id: 1,
    bookId: 2,
    userId: 1,
    startDate: "2025-11-20",
    endDate: "2025-12-20",
    returned: false
  },
  {
    id: 2,
    bookId: 6,
    userId: 2,
    startDate: "2025-11-18",
    endDate: "2025-12-18",
    returned: false
  },
  {
    id: 3,
    bookId: 11,
    userId: 1,
    startDate: "2025-11-15",
    endDate: "2025-12-15",
    returned: false
  }
];
