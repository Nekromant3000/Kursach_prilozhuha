import { Link } from 'react-router-dom';
import { Book } from '../types';
import { Calendar } from 'lucide-react';

interface BookCardProps {
  book: Book;
}

export const BookCard = ({ book }: BookCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-[3/4] overflow-hidden bg-gray-100">
        <img
          src={book.image}
          alt={book.title}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-1 line-clamp-2">
          {book.title}
        </h3>

        <p className="text-sm text-gray-600 mb-2">{book.author}</p>

        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
            {book.genre}
          </span>
          <span className="text-xs text-gray-500 flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {book.year}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span
            className={`text-xs font-medium px-2 py-1 rounded ${
              book.available
                ? 'bg-green-100 text-green-700'
                : 'bg-red-100 text-red-700'
            }`}
          >
            {book.available ? 'В наличии' : 'Выдана'}
          </span>

          <Link
            to={`/books/${book.id}`}
            className="text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            Подробнее →
          </Link>
        </div>
      </div>
    </div>
  );
};
