import { apiClient } from './client';
import { BorrowRequest, BorrowingWithBook } from '../types';

export interface BorrowResponse {
  message: string;
  borrowing: BorrowingWithBook;
}


export const borrowingsApi = {
  borrowBook: async (data: BorrowRequest): Promise<BorrowResponse> => {
    return apiClient<BorrowResponse>('/borrow', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  returnBook: async (borrowingId: number): Promise<{ message: string }> => {
    return apiClient<{ message: string }>(`/return/${borrowingId}`, {
      method: 'POST',
    });
  },

  getMyBorrowings: async (): Promise<BorrowingWithBook[]> => {
    return apiClient<BorrowingWithBook[]>('/borrow/my');
  },
};
