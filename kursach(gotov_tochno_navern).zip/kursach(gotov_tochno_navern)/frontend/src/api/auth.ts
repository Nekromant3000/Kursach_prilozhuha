import { apiClient, setAuthToken, removeAuthToken } from './client';
import { LoginRequest, RegisterRequest, AuthResponse, User } from '../types';

export const authApi = {
  login: async (data: LoginRequest): Promise<AuthResponse> => {
    const response = await apiClient<AuthResponse>('/login', {
      method: 'POST',
      body: JSON.stringify(data),
    });

    setAuthToken(response.access_token);
    return response;
  },

  register: async (data: RegisterRequest): Promise<AuthResponse> => {
    const response = await apiClient<AuthResponse>('/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });

    setAuthToken(response.access_token);
    return response;
  },

  getCurrentUser: async (): Promise<User> => {
    return apiClient<User>('/me');
  },

  logout: (): void => {
    removeAuthToken();
  },
};
