# Руководство по настройке SQLite бэкенда

## Быстрый старт

### 1. Установите зависимости

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Инициализируйте БД

```bash
python init_db.py
```

Это создаст файл `library.db` с тестовыми данными.

### 3. Запустите сервер

```bash
uvicorn main:app --reload
```

Сервер будет доступен на: `http://localhost:8000`

## Документация API

После запуска откройте: `http://localhost:8000/docs`

## Тестовые учетные данные

```
Email: reader@example.com
Пароль: password123

Email: admin@example.com
Пароль: password123
```

## Структура файлов

```
backend/
├── core/
│   ├── __init__.py
│   └── security.py         # JWT токены и хеширование паролей
├── routers/
│   ├── __init__.py
│   ├── auth.py             # Регистрация и вход
│   ├── books.py            # Работа с книгами
│   └── borrowings.py       # Выдача и возврат книг
├── database.py             # Подключение к SQLite
├── models.py               # SQLAlchemy модели
├── schemas.py              # Pydantic схемы
├── crud.py                 # CRUD операции
├── main.py                 # FastAPI приложение
├── init_db.py              # Инициализация данных
├── requirements.txt        # Зависимости
├── README.md               # Документация
└── SETUP_GUIDE.md          # Этот файл
```

## API Эндпоинты

### Аутентификация

```
POST /api/register     - Регистрация
POST /api/login        - Вход
GET  /api/me           - Информация о пользователе
```

### Книги

```
GET  /api/books        - Список книг (с фильтрацией)
GET  /api/books/{id}   - Информация о книге
```

### Выдача книг

```
POST /api/borrow       - Взять книгу
GET  /api/borrow/my    - Мои книги
POST /api/return/{id}  - Вернуть книгу
```

### Статистика

```
GET  /api/stats        - Статистика библиотеки
```

## Примеры запросов

### Вход

```bash
curl -X POST "http://localhost:8000/api/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "reader@example.com",
    "password": "password123"
  }'
```

Ответ:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "Иван Петров",
    "email": "reader@example.com",
    "role": "reader"
  }
}
```

### Получить список книг

```bash
curl "http://localhost:8000/api/books?genre=Роман&page=1"
```

### Взять книгу

```bash
TOKEN="your_access_token_here"
curl -X POST "http://localhost:8000/api/borrow" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "book_id": 1,
    "start_date": "2025-12-08",
    "end_date": "2026-01-08"
  }'
```

## Интеграция с фронтендом

Отредактируйте `src/api/client.ts` в проекте фронтенда:

```typescript
const API_BASE = 'http://localhost:8000/api';
```

Затем отключите MSW моки в `src/main.tsx`:

```typescript
// Просто удалите вызов enableMocking()
```

Перезагрузите фронтенд и используйте реальный API!

## Развертывание

### Локально

```bash
python init_db.py
uvicorn main:app
```

### На Vercel/Heroku

Замените SQLite на PostgreSQL в `database.py`:

```python
SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL")
```

## Важные заметки

- `library.db` создается автоматически при первом запуске
- Все таблицы создаются автоматически через `Base.metadata.create_all()`
- Пароли хешируются с помощью bcrypt
- Токены JWT выдаются на 7 дней (можно изменить в `core/security.py`)

## Проблемы и решения

### ModuleNotFoundError

Убедитесь что виртуальное окружение активировано и все зависимости установлены:

```bash
pip install -r requirements.txt
```

### "Port 8000 is already in use"

Используйте другой порт:

```bash
uvicorn main:app --port 8001
```

### "Database is locked"

Это нормально для SQLite при одновременных запросах. Перезагрузите сервер.

## Дополнительные команды

```bash
# Удалить БД и пересоздать
rm library.db
python init_db.py

# Запустить с определенной версией Python
python3.9 init_db.py

# Запустить в фоне (Linux/Mac)
nohup uvicorn main:app &

# Посмотреть логи
tail -f nohup.out
```

## Что дальше?

1. Запустите фронтенд: `npm run dev`
2. Запустите бэкенд: `uvicorn main:app --reload`
3. Откройте `http://localhost:5173`
4. Вход с учетными данными выше
5. Тестируйте приложение!

Готово! 🚀
