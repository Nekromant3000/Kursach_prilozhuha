import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { ArrowLeft, Calendar, CheckCircle, AlertCircle } from 'lucide-react';
import { useBook } from '../hooks/useBooks';
import { useBorrowBook } from '../hooks/useBorrowings';

interface BorrowFormData {
  startDate: string;
  endDate: string;
}

export const Borrow = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: book, isLoading } = useBook(Number(id));
  const borrowMutation = useBorrowBook();
  const [success, setSuccess] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<BorrowFormData>({
    defaultValues: {
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
    },
  });

  const onSubmit = async (data: BorrowFormData) => {
    try {
      await borrowMutation.mutateAsync({
        bookId: Number(id),
        startDate: data.startDate,
        endDate: data.endDate,
      });
      setSuccess(true);
      setTimeout(() => {
        navigate('/my-books');
      }, 2000);
    } catch {
      // Error handled by mutation
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!book || !book.available) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
          Книга недоступна для выдачи
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Книга успешно выдана!</h2>
          <p className="text-gray-600">Перенаправление на страницу "Мои книги"...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <button
          onClick={() => navigate(`/books/${id}`)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Назад к книге
        </button>

        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">Выдача книги</h1>

            <div className="bg-gray-50 rounded-lg p-4 mb-8">
              <div className="flex gap-4">
                <img
                  src={book.image}
                  alt={book.title}
                  className="w-24 h-32 object-cover rounded"
                />
                <div>
                  <h2 className="font-semibold text-gray-900 mb-1">{book.title}</h2>
                  <p className="text-sm text-gray-600 mb-2">{book.author}</p>
                  <p className="text-xs text-gray-500">{book.genre}, {book.year}</p>
                </div>
              </div>
            </div>

            {borrowMutation.error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-800">
                  {borrowMutation.error instanceof Error
                    ? borrowMutation.error.message
                    : 'Ошибка при выдаче книги'}
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-2">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Дата выдачи
                  </div>
                </label>
                <input
                  {...register('startDate', {
                    required: 'Дата выдачи обязательна',
                  })}
                  type="date"
                  id="startDate"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {errors.startDate && (
                  <p className="mt-1 text-sm text-red-600">{errors.startDate.message}</p>
                )}
              </div>

              <div>
                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-2">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Дата возврата (дедлайн)
                  </div>
                </label>
                <input
                  {...register('endDate', {
                    required: 'Дата возврата обязательна',
                  })}
                  type="date"
                  id="endDate"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {errors.endDate && (
                  <p className="mt-1 text-sm text-red-600">{errors.endDate.message}</p>
                )}
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  Пожалуйста, верните книгу до указанной даты. При задержке возврата могут быть применены штрафные санкции.
                </p>
              </div>

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => navigate(`/books/${id}`)}
                  className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={borrowMutation.isPending}
                  className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {borrowMutation.isPending ? 'Оформление...' : 'Подтвердить выдачу'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
