import { useQuery } from '@tanstack/react-query';
import { booksApi, BooksFilters } from '../api/books';

export const useBooks = (filters: BooksFilters = {}) => {
  return useQuery({
    queryKey: ['books', filters],
    queryFn: () => booksApi.getBooks(filters),
  });
};

export const useBook = (id: number) => {
  return useQuery({
    queryKey: ['book', id],
    queryFn: () => booksApi.getBookById(id),
    enabled: !!id,
  });
};
