import { useState } from 'react';
import { Calendar, RotateCcw, BookOpen, CheckCircle } from 'lucide-react';
import { useMyBorrowings, useReturnBook } from '../hooks/useBorrowings';

export const MyBooks = () => {
  const { data: borrowings, isLoading } = useMyBorrowings();
  const returnMutation = useReturnBook();
  const [returnedId, setReturnedId] = useState<number | null>(null);

  const handleReturn = async (borrowingId: number) => {
    try {
      await returnMutation.mutateAsync(borrowingId);
      setReturnedId(borrowingId);
      setTimeout(() => setReturnedId(null), 2000);
    } catch {
      // Error handled by mutation
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Мои книги</h1>
          <p className="text-gray-600">Книги, которые вы взяли из библиотеки</p>
        </div>

        {borrowings && borrowings.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
              <BookOpen className="w-8 h-8 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              У вас пока нет взятых книг
            </h2>
            <p className="text-gray-600 mb-6">
              Посетите каталог и выберите книгу для чтения
            </p>
            <a
              href="/"
              className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Перейти в каталог
            </a>
          </div>
        ) : (
          <div className="space-y-4">
            {borrowings?.map((borrowing) => (
              <div
                key={borrowing.id}
                className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
              >
                <div className="flex flex-col md:flex-row gap-6 p-6">
                  <div className="flex-shrink-0">
                    <img
                      src={borrowing.book.image}
                      alt={borrowing.book.title}
                      className="w-32 h-44 object-cover rounded-lg shadow-sm"
                    />
                  </div>

                  <div className="flex-1">
                    <h2 className="text-xl font-semibold text-gray-900 mb-2">
                      {borrowing.book.title}
                    </h2>
                    <p className="text-gray-600 mb-4">{borrowing.book.author}</p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span className="font-medium">Дата выдачи:</span>
                        <span>{new Date(borrowing.start_date).toLocaleDateString('ru-RU')}</span>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span className="font-medium">Вернуть до:</span>
                        <span
                          className={
                            new Date(borrowing.end_date) < new Date()
                              ? 'text-red-600 font-semibold'
                              : ''
                          }
                        >
                          {new Date(borrowing.end_date).toLocaleDateString('ru-RU')}
                        </span>
                      </div>
                    </div>

                    {new Date(borrowing.end_date) < new Date() && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                        <p className="text-sm text-red-800 font-medium">
                          Срок возврата истёк! Пожалуйста, верните книгу как можно скорее.
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center">
                    {returnedId === borrowing.id ? (
                      <div className="flex items-center gap-2 px-6 py-3 bg-green-100 text-green-700 rounded-lg">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-medium">Возвращено</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleReturn(borrowing.id)}
                        disabled={returnMutation.isPending}
                        className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <RotateCcw className="w-5 h-5" />
                        Вернуть книгу
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
