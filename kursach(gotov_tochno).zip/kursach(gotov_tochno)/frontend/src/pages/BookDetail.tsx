import { useParams, useNavigate, Link } from 'react-router-dom';
import { Calendar, User, Tag, ArrowLeft, BookOpen } from 'lucide-react';
import { useBook } from '../hooks/useBooks';
import { useAuth } from '../context/AuthContext';

export const BookDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { data: book, isLoading, error } = useBook(Number(id));

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !book) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
          Книга не найдена
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Назад к каталогу
        </button>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-8">
            <div className="md:col-span-1">
              <div className="aspect-[3/4] rounded-lg overflow-hidden bg-gray-100 shadow-md">
                <img
                  src={book.image}
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <div className="mb-6">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{book.title}</h1>
                <p className="text-xl text-gray-600">{book.author}</p>
              </div>

              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex items-center gap-2 text-gray-700">
                  <Tag className="w-5 h-5 text-gray-500" />
                  <span className="font-medium">Жанр:</span>
                  <span>{book.genre}</span>
                </div>

                <div className="flex items-center gap-2 text-gray-700">
                  <Calendar className="w-5 h-5 text-gray-500" />
                  <span className="font-medium">Год:</span>
                  <span>{book.year}</span>
                </div>
              </div>

              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-3">Описание</h2>
                <p className="text-gray-700 leading-relaxed">{book.description}</p>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <div className="flex items-center gap-4 mb-6">
                  <span className="text-lg font-semibold text-gray-900">Статус:</span>
                  <span
                    className={`px-4 py-2 rounded-lg font-medium ${
                      book.available
                        ? 'bg-green-100 text-green-700'
                        : 'bg-red-100 text-red-700'
                    }`}
                  >
                    {book.available ? 'В наличии' : 'Выдана'}
                  </span>
                </div>

                {!book.available && book.borrowing && (
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <User className="w-5 h-5" />
                      Информация о выдаче
                    </h3>
                    <div className="space-y-2 text-sm text-gray-700">
                      <p>
                        <span className="font-medium">Дата выдачи:</span>{' '}
                        {new Date(book.borrowing.startDate).toLocaleDateString('ru-RU')}
                      </p>
                      <p>
                        <span className="font-medium">Дата возврата:</span>{' '}
                        {new Date(book.borrowing.endDate).toLocaleDateString('ru-RU')}
                      </p>
                    </div>
                  </div>
                )}

                {book.available && (
                  <div>
                    {isAuthenticated ? (
                      <Link
                        to={`/borrow/${book.id}`}
                        className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                      >
                        <BookOpen className="w-5 h-5" />
                        Взять книгу
                      </Link>
                    ) : (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <p className="text-sm text-blue-800 mb-3">
                          Для того чтобы взять книгу, необходимо войти в систему
                        </p>
                        <Link
                          to="/login"
                          className="inline-block px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          Войти
                        </Link>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
