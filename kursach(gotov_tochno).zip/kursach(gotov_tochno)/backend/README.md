# Library Management API

Бэкенд приложения для управления библиотекой на FastAPI + SQLite.

## Требования

- Python 3.9+

## Установка

1. Создайте виртуальное окружение:

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

2. Установите зависимости:

```bash
pip install -r requirements.txt
```

## Запуск

```bash
uvicorn main:app --reload
```

Приложение будет доступно по адресу: `http://localhost:8000`

## Документация API

После запуска откройте:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## API Эндпоинты

### Аутентификация

- `POST /api/register` - Регистрация нового пользователя
- `POST /api/login` - Вход в систему
- `GET /api/me` - Информация о текущем пользователе

### Книги

- `GET /api/books` - Список всех книг (с фильтрацией и поиском)
- `GET /api/books/{id}` - Информация о конкретной книге

### Выдача книг

- `POST /api/borrow` - Взять книгу
- `GET /api/borrow/my` - Список моих книг
- `POST /api/return/{id}` - Вернуть книгу

### Статистика

- `GET /api/stats` - Статистика библиотеки

## Структура проекта

```
backend/
├── core/
│   ├── __init__.py
│   └── security.py         # JWT токены и аутентификация
├── routers/
│   ├── __init__.py
│   ├── auth.py             # Эндпоинты регистрации и входа
│   ├── books.py            # Эндпоинты работы с книгами
│   └── borrowings.py       # Эндпоинты выдачи/возврата
├── database.py             # Подключение к БД
├── models.py               # SQLAlchemy модели
├── schemas.py              # Pydantic схемы
├── crud.py                 # CRUD операции
├── main.py                 # FastAPI приложение
└── requirements.txt        # Зависимости
```

## Примеры запросов

### Регистрация

```bash
curl -X POST "http://localhost:8000/api/register" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Иван Петров",
    "email": "ivan@example.com",
    "password": "password123"
  }'
```

### Вход

```bash
curl -X POST "http://localhost:8000/api/login" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Иван Петров",
    "email": "ivan@example.com",
    "password": "password123"
  }'
```

### Получить список книг

```bash
curl "http://localhost:8000/api/books?genre=Роман&page=1"
```

### Взять книгу

```bash
TOKEN="your_token_here"
curl -X POST "http://localhost:8000/api/borrow" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "book_id": 1,
    "start_date": "2025-12-08",
    "end_date": "2026-01-08"
  }'
```

## Инициализация БД с тестовыми данными

Создайте файл `init_db.py`:

```python
from database import Base, engine, SessionLocal
from models import Book
import models

Base.metadata.create_all(bind=engine)

db = SessionLocal()

books = [
    {
        "title": "Мастер и Маргарита",
        "author": "Михаил Булгаков",
        "genre": "Роман",
        "year": 1967,
        "description": "Роман Михаила Булгакова...",
        "image": "https://images.pexels.com/photos/256450/pexels-photo-256450.jpeg"
    },
    # ... еще книги
]

for book_data in books:
    book = Book(**book_data, available=True)
    db.add(book)

db.commit()
db.close()
```

Запустите: `python init_db.py`
