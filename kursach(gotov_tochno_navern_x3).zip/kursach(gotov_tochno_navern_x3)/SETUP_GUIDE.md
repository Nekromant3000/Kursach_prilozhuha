# Руководство по развертыванию

## Локальный запуск

```bash
1. Установите Docker и Docker Compose
2. Скопируйте файлы проекта
3. Запустите:
docker-compose up --build -d

# Развертывание на сервере

1. Подключитесь к серверу (Yandex.Cloud/VPS)
2. Установите Docker:

curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

3. Скопируйте проект на сервер
4. Запустите: docker-compose up --build -d
5. Откройте порты 3000 и 8000 в firewall

# Настройка окружения

Backend (.env)

DATABASE_URL=sqlite:////data/library.db
SECRET_KEY=ваш-секретный-ключ
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=10080

Frontend (.env)

VITE_API_URL=http://backend:8000/api
VITE_APP_NAME=Библиотека

# Проверка работоспособности

 http://сервер:3000 - загружается интерфейс

 http://сервер:8000/docs - доступна документация API

 http://сервер:8000/health - статус "healthy"

# Обновление

git pull origin main
docker-compose up --build -d

# Решение проблем

Порты заняты: Измените порты в docker-compose.yml

Ошибка сборки:
docker system prune -a
docker-compose build --no-cache

Логи: docker-compose logs -f