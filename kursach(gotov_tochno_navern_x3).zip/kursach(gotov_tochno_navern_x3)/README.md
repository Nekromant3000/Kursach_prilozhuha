# Библиотека - система выдачи книг

Веб-приложение для управления библиотечным фондом с системой учета выдачи книг.

## Быстрый запуск

1. Установите Docker и Docker Compose
2. Клонируйте проект
3. Выполните: `docker-compose up --build`

Приложение будет доступно:
- Интерфейс: http://localhost:3000
- API: http://localhost:8000
- Документация API: http://localhost:8000/docs

## Технологии

- **Frontend**: React + TypeScript + Vite + Tailwind CSS
- **Backend**: FastAPI + SQLite + JWT
- **База данных**: SQLite с Docker volume

## Структура

backend/ - FastAPI сервер
frontend/ - React приложение
docker-compose.yml - конфигурация Docker

Для подробной инструкции по развертыванию см. SETUP_GUIDE.md