import { apiClient } from './client';
import { Book } from '../types';

export interface BooksResponse {
  data: Book[];
  total: number;
  page: number;
  totalPages: number;
}

export interface BookDetailResponse extends Book {
  borrowing: {
    userId: number;
    startDate: string;
    endDate: string;
  } | null;
}

export interface BooksFilters {
  genre?: string;
  author?: string;
  year?: number;
  search?: string;
  page?: number;
}

export const booksApi = {
  getBooks: async (filters: BooksFilters = {}): Promise<BooksResponse> => {
    const params = new URLSearchParams();

    if (filters.genre) params.append('genre', filters.genre);
    if (filters.author) params.append('author', filters.author);
    if (filters.year) params.append('year', filters.year.toString());
    if (filters.search) params.append('search', filters.search);
    if (filters.page) params.append('page', filters.page.toString());

    const queryString = params.toString();
    const endpoint = queryString ? `/books?${queryString}` : '/books';

    return apiClient<BooksResponse>(endpoint);
  },

  getBookById: async (id: number): Promise<BookDetailResponse> => {
    return apiClient<BookDetailResponse>(`/books/${id}`);
  },
};
