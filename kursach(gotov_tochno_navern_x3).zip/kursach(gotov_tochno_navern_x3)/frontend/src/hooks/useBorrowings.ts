import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { borrowingsApi } from '../api/borrowings';
import { BorrowRequest } from '../types';

export const useBorrowBook = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: BorrowRequest) => borrowingsApi.borrowBook(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      queryClient.invalidateQueries({ queryKey: ['myBorrowings'] });
    },
  });
};

export const useReturnBook = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (borrowingId: number) => borrowingsApi.returnBook(borrowingId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      queryClient.invalidateQueries({ queryKey: ['myBorrowings'] });
    },
  });
};

export const useMyBorrowings = () => {
  return useQuery({
    queryKey: ['myBorrowings'],
    queryFn: () => borrowingsApi.getMyBorrowings(),
  });
};
