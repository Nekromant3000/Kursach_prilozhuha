from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from database import get_db
from routers import auth, books, borrowings

app = FastAPI(title="Library Management API", version="1.0.0")

app.mount("/static", StaticFiles(directory="static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://frontend:3000"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(books.router)
app.include_router(borrowings.router)


@app.get("/")
def read_root():
    return {"message": "Library Management API is running!"}


@app.get("/health")
def health_check():
    return {"status": "healthy"}


@app.get("/api/stats")
def get_library_stats(db: Session = Depends(get_db)):
    from models import Book, Borrowing

    total_books = db.query(Book).count()
    available_books = db.query(Book).filter(Book.available == True).count()
    active_borrowings = db.query(Borrowing).filter(Borrowing.returned == False).count()

    return {
        "total_books": total_books,
        "available_books": available_books,
        "borrowed_books": active_borrowings
    }
