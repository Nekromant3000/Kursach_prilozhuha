from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from datetime import date
import models
import schemas
from core.security import verify_password, get_password_hash


def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()


def get_user_by_id(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()


def create_user(db: Session, user: schemas.UserCreate):
    db_user = models.User(
        name=user.name or user.email.split("@")[0],
        email=user.email,
        hashed_password=get_password_hash(user.password),
        role="reader"
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def authenticate_user(db: Session, email: str, password: str):
    user = get_user_by_email(db, email)
    if not user or not verify_password(password, user.hashed_password):
        return None
    return user


def get_books(
    db: Session,
    skip: int = 0,
    limit: int = 10,
    genre: str = None,
    author: str = None,
    year_from: int = None,
    year_to: int = None,
    search: str = None
):
    query = db.query(models.Book)

    if search:
        query = query.filter(
            or_(
                models.Book.title.ilike(f"%{search}%"),
                models.Book.description.ilike(f"%{search}%")
            )
        )

    if genre:
        query = query.filter(models.Book.genre == genre)

    if author:
        query = query.filter(models.Book.author == author)

    if year_from:
        query = query.filter(models.Book.year >= year_from)

    if year_to:
        query = query.filter(models.Book.year <= year_to)

    total = query.count()
    books = query.offset(skip).limit(limit).all()

    return {
        "data": books,
        "total": total,
        "page": (skip // limit) + 1,
        "total_pages": (total + limit - 1) // limit
    }


def get_book(db: Session, book_id: int):
    return db.query(models.Book).filter(models.Book.id == book_id).first()


def create_book(db: Session, book: schemas.BookCreate):
    db_book = models.Book(
        title=book.title,
        author=book.author,
        genre=book.genre,
        year=book.year,
        description=book.description,
        image=book.image,
        available=True
    )
    db.add(db_book)
    db.commit()
    db.refresh(db_book)
    return db_book


def borrow_book(
    db: Session,
    book_id: int,
    user_id: int,
    start_date: date,
    end_date: date
):
    book = get_book(db, book_id)
    if not book or not book.available:
        return None

    borrowing = models.Borrowing(
        book_id=book_id,
        user_id=user_id,
        start_date=start_date,
        end_date=end_date,
        returned=False
    )

    book.available = False

    db.add(borrowing)
    db.commit()
    db.refresh(borrowing)
    return borrowing


def return_book(db: Session, borrowing_id: int):
    borrowing = db.query(models.Borrowing).filter(
        models.Borrowing.id == borrowing_id
    ).first()

    if not borrowing:
        return None

    borrowing.returned = True
    book = get_book(db, borrowing.book_id)
    if book:
        book.available = True

    db.commit()
    db.refresh(borrowing)
    return borrowing


def get_user_borrowings(db: Session, user_id: int):
    return db.query(models.Borrowing).filter(
        and_(
            models.Borrowing.user_id == user_id,
            models.Borrowing.returned == False
        )
    ).all()


def get_borrowing(db: Session, borrowing_id: int):
    return db.query(models.Borrowing).filter(
        models.Borrowing.id == borrowing_id
    ).first()
