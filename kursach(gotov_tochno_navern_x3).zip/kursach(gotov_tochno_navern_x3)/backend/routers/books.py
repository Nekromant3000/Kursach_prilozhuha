from fastapi import APIRouter, Depends, HTTPException, status, Query, Response
from sqlalchemy.orm import Session
from typing import Optional

from database import get_db
import crud
import schemas

router = APIRouter(prefix="/api/books", tags=["Books"])


@router.get("/", response_model=schemas.BooksListResponse)
def read_books(
    skip: int = Query(0),
    page: int = Query(1),
    limit: int = Query(10),
    genre: Optional[str] = Query(None),
    author: Optional[str] = Query(None),
    year_from: Optional[int] = Query(None),
    year_to: Optional[int] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    skip = (page - 1) * limit
    return crud.get_books(
        db,
        skip=skip,
        limit=limit,
        genre=genre,
        author=author,
        year_from=year_from,
        year_to=year_to,
        search=search
    )


@router.get("/{book_id}", response_model=dict)
def read_book(book_id: int, db: Session = Depends(get_db)):
    book = crud.get_book(db, book_id=book_id)
    if not book:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Book not found"
        )

    borrowing_info = None
    active_borrowing = db.query(crud.models.Borrowing).filter(
        crud.models.Borrowing.book_id == book_id,
        crud.models.Borrowing.returned == False
    ).first()

    if active_borrowing:
        borrowing_info = {
            "userId": active_borrowing.user_id,
            "startDate": active_borrowing.start_date.isoformat(),
            "endDate": active_borrowing.end_date.isoformat()
        }

    return {
        "id": book.id,
        "title": book.title,
        "author": book.author,
        "genre": book.genre,
        "year": book.year,
        "description": book.description,
        "image": book.image,
        "available": book.available,
        "borrowing": borrowing_info
    }


@router.post("/", response_model=schemas.BookResponse)
def create_book(book: schemas.BookCreate, db: Session = Depends(get_db)):
    return crud.create_book(db, book=book)
