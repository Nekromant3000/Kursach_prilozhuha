from sqlalchemy import Column, Integer, String, Text, ForeignKey, Boolean, Date, UniqueConstraint
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    role = Column(String, default="reader")

    borrowings = relationship(
        "Borrowing",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    __table_args__ = (
        UniqueConstraint('email', name='uq_user_email'),
    )


class Book(Base):
    __tablename__ = "books"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    author = Column(String, index=True)
    genre = Column(String, index=True)
    year = Column(Integer)
    description = Column(Text)
    image = Column(String)
    available = Column(Boolean, default=True)

    borrowings = relationship(
        "Borrowing",
        back_populates="book",
        cascade="all, delete-orphan"
    )


class Borrowing(Base):
    __tablename__ = "borrowings"

    id = Column(Integer, primary_key=True, index=True)
    book_id = Column(Integer, ForeignKey("books.id"), index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    start_date = Column(Date)
    end_date = Column(Date)
    returned = Column(Boolean, default=False)

    book = relationship("Book", back_populates="borrowings")
    user = relationship("User", back_populates="borrowings")

    __table_args__ = (
        UniqueConstraint('book_id', 'user_id', 'returned', name='uq_active_borrowing'),
    )
