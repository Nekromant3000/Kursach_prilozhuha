export interface User {
  id: number;
  name: string;
  email: string;
  role: "reader" | "admin";
}

export interface Book {
  id: number;
  title: string;
  author: string;
  genre: string;
  year: number;
  image: string;
  description: string;
  available: boolean;
}

export interface Borrowing {
  id: number;
  book_id: number;
  user_id: number;
  start_date: string;
  end_date: string;
  returned: boolean;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
}

export interface AuthResponse {
  access_token: string;
  user: User;
}

export interface BorrowRequest {
  bookId: number;
  startDate: string;
  endDate: string;
}

export interface BorrowingWithBook extends Borrowing {
  book: Book;
}