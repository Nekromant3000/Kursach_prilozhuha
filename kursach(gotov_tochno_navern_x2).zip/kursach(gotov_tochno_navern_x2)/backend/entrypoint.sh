#!/bin/bash

# Ожидаем инициализации базы данных
echo "Ожидание инициализации базы данных..."

# Проверяем, существует ли файл базы данных
if [ ! -f /data/library.db ]; then
    echo "База данных не найдена, запускаем инициализацию..."
    python init_db.py
else
    echo "База данных уже существует, пропускаем инициализацию."
fi

# Проверяем зависимости bcrypt
python -c "import bcrypt; print(f'bcrypt version: {bcrypt.__version__}')" || echo "Warning: bcrypt version check failed"

# Запускаем приложение
uvicorn main:app --host 0.0.0.0 --port 8000 --reload