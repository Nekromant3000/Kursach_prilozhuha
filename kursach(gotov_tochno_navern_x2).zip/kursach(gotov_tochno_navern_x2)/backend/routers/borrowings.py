from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from core.security import verify_token
import crud
import schemas

router = APIRouter(prefix="/api", tags=["Borrowings"])


@router.post("/borrow", response_model=schemas.BorrowResponse)
def borrow_book(
    borrowing: schemas.BorrowingCreate,
    user_id: int = Depends(verify_token),
    db: Session = Depends(get_db)
):
    book = crud.get_book(db, borrowing.book_id)

    if not book:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Book not found"
        )

    if not book.available:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Book is not available"
        )

    db_borrowing = crud.borrow_book(
        db,
        book_id=borrowing.book_id,
        user_id=user_id,
        start_date=borrowing.start_date,
        end_date=borrowing.end_date
    )

    return {
        "message": "Book borrowed successfully",
        "borrowing": schemas.BorrowingResponse.from_orm(db_borrowing)
    }


@router.post("/return/{borrowing_id}")
def return_book(
    borrowing_id: int,
    user_id: int = Depends(verify_token),
    db: Session = Depends(get_db)
):
    borrowing = crud.get_borrowing(db, borrowing_id)

    if not borrowing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Borrowing not found"
        )

    if borrowing.user_id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Unauthorized"
        )

    crud.return_book(db, borrowing_id)

    return {"message": "Book returned successfully"}


@router.get("/borrow/my", response_model=List[schemas.BorrowingDetailResponse])
def get_my_borrowings(
    user_id: int = Depends(verify_token),
    db: Session = Depends(get_db)
):
    borrowings = crud.get_user_borrowings(db, user_id=user_id)

    result = []
    for borrowing in borrowings:
        book = crud.get_book(db, borrowing.book_id)
        result.append({
            "id": borrowing.id,
            "book_id": borrowing.book_id,
            "user_id": borrowing.user_id,
            "start_date": borrowing.start_date,
            "end_date": borrowing.end_date,
            "returned": borrowing.returned,
            "book": {
                "id": book.id,
                "title": book.title,
                "author": book.author,
                "genre": book.genre,
                "year": book.year,
                "description": book.description,
                "image": book.image,
                "available": book.available
            }
        })

    return result
