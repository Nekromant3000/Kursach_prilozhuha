from database import Base, engine, SessionLocal
from models import Book, User
from passlib.context import CryptContext
from core.security import pwd_context
import os

db_dir = "/data"
if not os.path.exists(db_dir):
    os.makedirs(db_dir, exist_ok=True)
    print(f"Created directory: {db_dir}")

Base.metadata.create_all(bind=engine)

db = SessionLocal()

books_data = [
    {
        "title": "Мастер и Маргарита",
        "author": "Михаил Булгаков",
        "genre": "Роман",
        "year": 1967,
        "description": "Роман Михаила Булгакова, работа над которым началась в конце 1920-х годов и продолжалась вплоть до смерти писателя.",
        "image": "/static/images/masterm.webp"
    },
    {
        "title": "Война и мир",
        "author": "Лев Толстой",
        "genre": "Роман-эпопея",
        "year": 1869,
        "description": "Роман-эпопея Льва Толстого, описывающий русское общество в эпоху войн против Наполеона в 1805—1812 годах.",
        "image": "/static/images/voynam.webp"
    },
    {
        "title": "Преступление и наказание",
        "author": "Фёдор Достоевский",
        "genre": "Роман",
        "year": 1866,
        "description": "Социально-философский и социально-психологический роман Фёдора Достоевского.",
        "image": "/static/images/prest.webp"
    },
    {
        "title": "Евгений Онегин",
        "author": "Александр Пушкин",
        "genre": "Роман в стихах",
        "year": 1833,
        "description": "Роман в стихах Александра Пушкина, одно из самых значительных произведений русской словесности.",
        "image": "/static/images/evgenyo.webp"
    },
    {
        "title": "Анна Каренина",
        "author": "Лев Толстой",
        "genre": "Роман",
        "year": 1877,
        "description": "Роман Льва Толстого о трагической любви замужней дамы Анны Карениной и блестящего офицера Вронского.",
        "image": "/static/images/annak.webp"
    },
    {
        "title": "Мёртвые души",
        "author": "Николай Гоголь",
        "genre": "Поэма",
        "year": 1842,
        "description": "Прозаическая поэма Николая Гоголя, одно из выдающихся произведений русской литературы.",
        "image": "/static/images/mertvd.webp"
    },
    {
        "title": "Идиот",
        "author": "Фёдор Достоевский",
        "genre": "Роман",
        "year": 1869,
        "description": "Роман Фёдора Достоевского, в котором писатель впервые с подлинной страстью воплотил давно задуманный образ.",
        "image": "/static/images/idiot.webp"
    },
    {
        "title": "Герой нашего времени",
        "author": "Михаил Лермонтов",
        "genre": "Роман",
        "year": 1840,
        "description": "Первый в русской прозе лирико-психологический роман, написанный Михаилом Лермонтовым.",
        "image": "/static/images/geroyn.webp"
    },
    {
        "title": "Отцы и дети",
        "author": "Иван Тургенев",
        "genre": "Роман",
        "year": 1862,
        "description": "Роман Ивана Тургенева, написанный в 1860—1861 годах и опубликованный в 1862 году.",
        "image": "/static/images/otcidet.webp"
    },
    {
        "title": "Вишнёвый сад",
        "author": "Антон Чехов",
        "genre": "Пьеса",
        "year": 1904,
        "description": "Пьеса в четырёх действиях Антона Чехова, жанр которой сам автор определил как комедию.",
        "image": "/static/images/vishnsad.jpg"
    },
    {
        "title": "Братья Карамазовы",
        "author": "Фёдор Достоевский",
        "genre": "Роман",
        "year": 1880,
        "description": "Последний роман Фёдора Достоевского, над которым писатель работал два года.",
        "image": "/static/images/bratkaram.webp"
    },
    {
        "title": "Обломов",
        "author": "Иван Гончаров",
        "genre": "Роман",
        "year": 1859,
        "description": "Роман Ивана Гончарова, написанный в 1859 году. Один из самых известных романов русской литературы.",
        "image": "/static/images/oblom.webp"
    }
]

# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

users_data = [
    {
        "name": "Иван Петров",
        "email": "reader@example.com",
        "password": "password123",
        "role": "reader"
    },
    {
        "name": "Мария Сидорова",
        "email": "admin@example.com",
        "password": "password123",
        "role": "admin"
    }
]

existing_books = db.query(Book).count()
if existing_books == 0:
    for book_data in books_data:
        book = Book(
            **book_data,
            available=True
        )
        db.add(book)
    db.commit()
    print(f"Created {len(books_data)} books")

# test_user = db.query(User).filter(User.email == "test@example.com").first()
# if not test_user:
    # Простой пароль для теста - в продакшене используйте bcrypt!
#     test_user = User(
#         name="Тестовый Пользователь",
#         email="test@example.com",
#         hashed_password="password123",  # В реальном приложении это должен быть хеш!
#         role="reader"
#     )
#     db.add(test_user)
#     db.commit()
#     print("Created test user (email: test@example.com, password: password123)")

existing_users = db.query(User).count()
if existing_users == 0:
    for user_data in users_data:
        password = user_data["password"]
        # Обрезаем до 72 байтов для безопасности bcrypt
        if len(password.encode('utf-8')) > 72:
            password = password[:72]  # Обрезаем строку до 72 байтов
        hashed_password = pwd_context.hash(password)
        user = User(
            name=user_data["name"],
            email=user_data["email"],
            hashed_password=hashed_password,
            role=user_data.get("role", "reader")
        )
        db.add(user)
    db.commit()
    print(f"Created {len(users_data)} users")

db.close()
print("Database initialized successfully!")
