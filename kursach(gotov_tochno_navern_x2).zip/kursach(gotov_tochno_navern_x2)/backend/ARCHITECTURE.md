# Архитектура SQLite бэкенда

## Обзор

```
┌─────────────────────────────────────────────┐
│         FastAPI приложение (main.py)        │
├─────────────────────────────────────────────┤
│  Роутеры:                                   │
│  - routers/auth.py       (регистрация)      │
│  - routers/books.py      (книги)            │
│  - routers/borrowings.py (выдача)           │
├─────────────────────────────────────────────┤
│  CRUD слой (crud.py):                       │
│  - Функции для работы с БД                  │
│  - Бизнес-логика                           │
├─────────────────────────────────────────────┤
│  Модели (models.py):                        │
│  - User        → users таблица              │
│  - Book        → books таблица              │
│  - Borrowing   → borrowings таблица         │
├─────────────────────────────────────────────┤
│         SQLite (library.db)                 │
└─────────────────────────────────────────────┘
```

## Слои приложения

### 1. API слой (routers/)

**auth.py** - Аутентификация
```python
POST /api/register  →  UserCreate    →  User
POST /api/login     →  UserCreate    →  AuthResponse
GET  /api/me        →  verify_token  →  UserResponse
```

**books.py** - Управление книгами
```python
GET  /api/books     →  query params  →  BooksListResponse
GET  /api/books/:id →  book_id       →  BookResponse
```

**borrowings.py** - Выдача и возврат
```python
POST /api/borrow    →  BorrowingCreate  →  BorrowResponse
POST /api/return    →  borrowing_id     →  {"message": "..."}
GET  /api/borrow/my →  user_id          →  List[BorrowingDetailResponse]
```

### 2. CRUD слой (crud.py)

Содержит все функции для работы с БД:

**Пользователи:**
- `get_user_by_email()` - найти по email
- `get_user_by_id()` - найти по ID
- `create_user()` - создать пользователя
- `authenticate_user()` - проверить пароль

**Книги:**
- `get_books()` - получить список с фильтрацией
- `get_book()` - получить одну книгу
- `create_book()` - добавить новую книгу

**Выдача:**
- `borrow_book()` - выдать книгу
- `return_book()` - вернуть книгу
- `get_user_borrowings()` - мои книги
- `get_borrowing()` - получить конкретную выдачу

**Утилиты:**
- `verify_password()` - проверить пароль
- `get_password_hash()` - захешировать пароль

### 3. Модели (models.py)

```python
class User
├─ id (Integer, PK)
├─ name (String)
├─ email (String, UNIQUE)
├─ hashed_password (String)
├─ role (String)  # "reader" или "admin"
└─ borrowings ← relationship

class Book
├─ id (Integer, PK)
├─ title (String)
├─ author (String)
├─ genre (String)
├─ year (Integer)
├─ description (Text)
├─ image (String)  # URL обложки
├─ available (Boolean)
└─ borrowings ← relationship

class Borrowing
├─ id (Integer, PK)
├─ book_id (ForeignKey → Book.id)
├─ user_id (ForeignKey → User.id)
├─ start_date (Date)
├─ end_date (Date)
├─ returned (Boolean)
├─ book ← relationship
└─ user ← relationship
```

### 4. Схемы (schemas.py)

Pydantic модели для валидации:

**Входящие:**
- `UserCreate` - для регистрации
- `BookCreate` - для добавления книги
- `BorrowingCreate` - для выдачи

**Исходящие:**
- `UserResponse` - информация о пользователе
- `BookResponse` - информация о книге
- `BorrowingResponse` - информация о выдаче
- `AuthResponse` - ответ при входе

### 5. Безопасность (core/security.py)

- `create_access_token()` - создать JWT токен
- `verify_token()` - проверить JWT токен
- `verify_password()` - проверить пароль bcrypt
- `get_password_hash()` - захешировать пароль bcrypt

## Поток данных

### Пример: Пользователь берет книгу

```
1. Фронтенд отправляет:
   POST /api/borrow
   {book_id: 1, start_date: "2025-12-08", end_date: "2026-01-08"}
   Authorization: Bearer token

2. Роутер (borrowings.py):
   - Проверяет токен: verify_token()
   - Валидирует данные: BorrowingCreate
   - Вызывает CRUD: crud.borrow_book()

3. CRUD слой:
   - Проверяет книгу: get_book()
   - Проверяет доступность
   - Создает запись в БД: models.Borrowing
   - Устанавливает available = False

4. БД (SQLite):
   INSERT INTO borrowings (book_id, user_id, start_date, end_date, returned)
   VALUES (1, 1, '2025-12-08', '2026-01-08', false)

   UPDATE books SET available = false WHERE id = 1

5. Ответ фронтенду:
   {
     "message": "Book borrowed successfully",
     "borrowing": {...}
   }

6. Фронтенд:
   - Показывает сообщение об успехе
   - Обновляет UI
```

## Особенности SQLite

### Преимущества
- ✅ Нет необходимости в отдельном сервере БД
- ✅ Быстро для разработки
- ✅ Простая развертка
- ✅ Файл базы находится локально

### Недостатки
- ⚠️ Не подходит для большого количества одновременных пользователей
- ⚠️ При развертывании нужна специальная конфигурация
- ⚠️ Менее надежна чем PostgreSQL/MySQL

### Для продакшена

Переключитесь на PostgreSQL:

```python
# database.py
from sqlalchemy import create_engine
import os

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://user:pass@localhost/library")

engine = create_engine(DATABASE_URL)
```

## Безопасность

### Хеширование паролей

```python
# При регистрации
hash = get_password_hash(password)  # bcrypt
user.hashed_password = hash

# При входе
verified = verify_password(password, user.hashed_password)  # bcrypt
```

### JWT токены

```python
# Создание
token = create_access_token({"sub": str(user.id)})

# Проверка
user_id = verify_token(token)  # Экстрактит user_id
```

### Защита маршрутов

```python
@router.post("/borrow")
def borrow_book(
    borrowing: BorrowingCreate,
    user_id: int = Depends(verify_token),  # ← Проверка авторизации
    db: Session = Depends(get_db)
):
    ...
```

## Производительность

### Индексы

Автоматически созданы на:
- `users.email`
- `books.title`, `books.author`, `books.genre`
- `borrowings.user_id`, `borrowings.book_id`

### Ограничения

- Max 100 MB для SQLite (в зависимости от платформы)
- Рекомендуется для < 10,000 записей
- Для продакшена используйте PostgreSQL

## Миграции

Миграции выполняются автоматически:

```python
# main.py
Base.metadata.create_all(bind=engine)
```

Это создает все таблицы при первом запуске.

## Тестирование

### Через Swagger UI

1. Откройте `http://localhost:8000/docs`
2. Нажмите "Try it out"
3. Заполните параметры
4. Нажмите "Execute"

### Через curl

```bash
curl -X POST http://localhost:8000/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"reader@example.com","password":"password123"}'
```

### Через Python requests

```python
import requests

response = requests.post(
    "http://localhost:8000/api/login",
    json={"email": "reader@example.com", "password": "password123"}
)
print(response.json())
```

## Расширение

### Добавить новый эндпоинт

1. Создайте функцию в `crud.py`
2. Создайте схемы в `schemas.py`
3. Добавьте маршрут в подходящий роутер
4. Используйте `Depends(verify_token)` если нужна авторизация

### Добавить новую таблицу

1. Добавьте класс в `models.py`
2. Наследуйте от `Base`
3. Используйте `relationship` для связей
4. Перезагрузите приложение (таблица создастся автоматически)

## Окончательно

Эта архитектура следует следующим принципам:
- **Разделение ответственности** - каждый слой отвечает за свое
- **DRY** - не повторяй себя (все в CRUD слое)
- **Простота** - легко понять и поддерживать
- **Масштабируемость** - легко добавлять новые функции

Архитектура может быть легко масштабирована или переведена на другую БД!
