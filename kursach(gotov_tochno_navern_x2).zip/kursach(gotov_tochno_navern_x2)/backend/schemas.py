from pydantic import BaseModel, Field, EmailStr, ConfigDict
from typing import Optional, List
from datetime import date


class UserBase(BaseModel):
    name: str
    email: EmailStr


class UserCreate(BaseModel):
    name: Optional[str] = None
    email: str
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    role: str

    class Config:
        from_attributes = True


class BookBase(BaseModel):
    title: str
    author: str
    genre: str
    year: int
    description: str
    image: str


class BookCreate(BookBase):
    pass


class BookResponse(BookBase):
    id: int
    available: bool

    class Config:
        from_attributes = True


class BorrowingBase(BaseModel):
    book_id: int
    user_id: int
    start_date: date
    end_date: date


class BorrowingCreate(BaseModel):
    book_id: int = Field(alias="bookId")
    start_date: date = Field(alias="startDate")
    end_date: date = Field(alias="endDate")

    model_config = ConfigDict(
        populate_by_name=True,  # Позволяет использовать оба варианта
        from_attributes=True
    )


class BorrowingResponse(BorrowingBase):
    id: int
    returned: bool

    class Config:
        from_attributes = True


class BorrowingDetailResponse(BaseModel):
    id: int
    book_id: int
    user_id: int
    start_date: date
    end_date: date
    returned: bool
    book: BookResponse

    class Config:
        from_attributes = True


class AuthResponse(BaseModel):
    access_token: str
    user: UserResponse


class BorrowResponse(BaseModel):
    message: str
    borrowing: BorrowingResponse

    class Config:
        from_attributes = True


class BooksListResponse(BaseModel):
    data: List[BookResponse]
    total: int
    page: int
    total_pages: int
